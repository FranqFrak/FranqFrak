# Projeto-SENAI-Event-Flow
Esse repositorio contem atividade em grupo de módulo de desenvolvimento de sistemas SENAI elaborado pela equipe: Marcio Intra; Henrique Freitas; Wesley Bastos, Kleiton Sobral.
