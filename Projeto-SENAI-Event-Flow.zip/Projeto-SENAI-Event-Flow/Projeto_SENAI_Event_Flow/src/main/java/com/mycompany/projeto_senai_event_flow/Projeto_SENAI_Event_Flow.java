/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.projeto_senai_event_flow;

/**
 *
 * @author marci
 */
public class Projeto_SENAI_Event_Flow {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
